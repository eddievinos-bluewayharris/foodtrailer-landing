# Food Trailer Landing Page

This is a basic landing page built with Vite + React and ready to deploy on Netlify.